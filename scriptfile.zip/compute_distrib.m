alpha = 1.6;
grid_size = 20;

d_max = floor(grid_size/2);
beta = sum((1 + (0:d_max)).^(-alpha))^-1;

vector_base = 1:grid_size^2;
vector_base(1) = beta;

for i=1:d_max
   
    for j=((2*i-1)^2+1):max((2*i+1)^2,length(vector_base))
       
        vector_base(j) = beta / (8 * i * (i+1)^alpha);
        
    end
    
end

disp(sum(vector_base));